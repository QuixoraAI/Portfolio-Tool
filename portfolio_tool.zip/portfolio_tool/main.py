"""
Quantitative Portfolio Construction & Backtesting Tool
--------------------------------------------------------
Run this file to:
  1. Pull historical prices + fundamentals for the configured universe
  2. Score and select assets using a value/quality/momentum composite
     (equities) and momentum (crypto)
  3. Build risk-based (inverse-volatility) target weights
  4. Walk-forward backtest the strategy vs. SPY and BTC benchmarks
  5. Print performance metrics + the current target portfolio
  6. Save a chart to output/performance.png

Usage:
    pip install -r requirements.txt
    python main.py
"""
import config
import data
import backtest
import report


def main():
    print("Fetching price history...")
    equity_prices = data.fetch_price_history(config.EQUITY_UNIVERSE, config.LOOKBACK_YEARS)
    crypto_prices = data.fetch_price_history(config.CRYPTO_UNIVERSE, config.LOOKBACK_YEARS)
    benchmark_prices = data.fetch_price_history(list(config.BENCHMARKS.keys()), config.LOOKBACK_YEARS)

    print("Fetching fundamentals (value/quality factors)...")
    fundamentals = data.fetch_fundamentals(equity_prices.columns.tolist())

    print("Running walk-forward backtest...")
    result = backtest.run_backtest(equity_prices, crypto_prices, fundamentals, config)
    metrics = backtest.performance_metrics(result["returns"], config.RISK_FREE_RATE)

    benchmark_metrics = {}
    benchmark_cumulative = {}
    for ticker, label in config.BENCHMARKS.items():
        bm_returns = benchmark_prices[ticker].pct_change()
        bm_returns = bm_returns.reindex(result["returns"].index).dropna()
        bm_metrics = backtest.performance_metrics(bm_returns, config.RISK_FREE_RATE)
        benchmark_metrics[label] = bm_metrics
        benchmark_cumulative[label] = bm_metrics["cumulative_series"]

    report.print_summary(metrics, benchmark_metrics, result["final_weights"])
    report.plot_performance(
        metrics["cumulative_series"],
        benchmark_cumulative,
        metrics["drawdown_series"],
        "output/performance.png",
    )
    print("Chart saved to output/performance.png")


if __name__ == "__main__":
    main()
